export interface Activity {
  id: string;
  name: string;
  category: 'simple' | 'medium' | 'high';
  basePrice: string;
  requirements?: string[]; // Specific requirements for this activity
  warningNote?: string;    // Custom warning for this activity
}

export const SALAMA_ACTIVITIES: Activity[] = [
  // --- Retail & Trade (التجزئة والمتاجرة) ---
  { 
    id: '471131', 
    name: 'البقالات', 
    category: 'simple', 
    basePrice: '69 ريال',
    requirements: ['طفايات حريق بودرة 6 كجم', 'كاشف دخان مستقل', 'لوحة إرشادية للمخرج'],
    warningNote: 'تأكد من عدم وجود تمديدات كهربائية عشوائية في منطقة المستودع الخلفي.'
  },
  { 
    id: '471132', 
    name: 'التموينات', 
    category: 'simple', 
    basePrice: '69 ريال',
    requirements: ['نظام كاميرات مراقبة', 'طفايات حريق يدوية', 'إنارة طوارئ'],
  },
  { 
    id: '477111', 
    name: 'البيع بالتجزئة للملابس الجاهزة الرجالية', 
    category: 'simple', 
    basePrice: '69 ريال',
    requirements: ['طفايات حريق CO2', 'كواشف دخان', 'الالتزام بمساحة العرض'],
  },
  { 
    id: '477112', 
    name: 'البيع بالتجزئة للملابس الجاهزة النسائية', 
    category: 'simple', 
    basePrice: '69 ريال',
    requirements: ['كواشف دخان حقلية', 'لوحات مخارج الطوارئ', 'طفايات حريق بودرة'],
  },
  { 
    id: '477211', 
    name: 'الصيدليات', 
    category: 'simple', 
    basePrice: '69 ريال',
    requirements: ['عقد صيانة أنظمة سلامة', 'طفايات حريق', 'مخرج طوارئ واضح'],
  },
  { id: '477331', name: 'البيع بالتجزئة للساعات بأنواعها', category: 'simple', basePrice: '69 ريال' },
  { id: '477361', name: 'البيع بالتجزئة للهدايا', category: 'simple', basePrice: '69 ريال' },
  { id: '477311', name: 'البيع بالتجزئة لكاميرات التصوير ومستلزماتها', category: 'simple', basePrice: '69 ريال' },
  { id: '477321', name: 'البيع بالتجزئة للعطور ومستحضرات التجميل', category: 'simple', basePrice: '99 ريال' },
  { id: '475911', name: 'البيع بالتجزئة للأثاث المنزلي', category: 'medium', basePrice: '150 ريال' },
  { id: '472111', name: 'البيع بالتجزئة للفواكه والخضروات', category: 'simple', basePrice: '69 ريال' },
  { id: '472112', name: 'البيع بالتجزئة للتمور', category: 'simple', basePrice: '69 ريال' },

  // --- Food & Beverage (الأغذية والمشروبات) ---
  { 
    id: '561010', 
    name: 'المطاعم مع الخدمة', 
    category: 'high', 
    basePrice: '350 ريال',
    requirements: ['نظام إخماد آلي للمطابخ (Ansul)', 'كاشف غاز مركزي', 'نظام تهوية وشفط معتمد'],
    warningNote: 'المطاعم تتطلب شهادة تركيب نظام غاز مركزي من شركة معتمدة.'
  },
  { 
    id: '561031', 
    name: 'محلات الوجبات السريعة ( تشمل محلات البيتزاء )', 
    category: 'medium', 
    basePrice: '200 ريال',
    requirements: ['طفايات حريق رغوية للمطبخ', 'نظام كشف حرارة', 'مخرج طوارئ إضافي'],
  },
  { 
    id: '563011', 
    name: 'محلات تقديم المشروبات (الكوفي شوب)', 
    category: 'medium', 
    basePrice: '150 ريال',
    requirements: ['تأريض الأجهزة الكهربائية', 'كواشف دخان', 'طفايات حريق بودرة'],
  },
  { id: '561021', name: 'البوفيهات ( الكافيتريات )', category: 'medium', basePrice: '150 ريال' },
  { id: '107110', name: 'صناعة الخبز البلدي المحلي', category: 'medium', basePrice: '150 ريال' },
  { id: '107120', name: 'صناعة الخبز ومنتجاته بواسطة المخابز الآلية', category: 'high', basePrice: '450 ريال' },
  { id: '107300', name: 'صُنع الكاكاو والشوكولاتة والحلويات السكرية', category: 'medium', basePrice: '250 ريال' },
  { id: '107911', name: 'تحميص البن أو طحنه أو تعبئته', category: 'medium', basePrice: '200 ريال' },

  // --- Industrial & Workshops (الصناعية والورش) ---
  { 
    id: '251151', 
    name: 'ورش الحدادة', 
    category: 'high', 
    basePrice: '400 ريال',
    requirements: ['نظام رش آلي (للمساحات الكبيرة)', 'ستائر عازلة للحام', 'أسطوانات غاز مؤمنة بمكان خارجي'],
    warningNote: 'يجب فصل منطقة العمليات الحرارية (اللحام) عن مناطق التخزين.'
  },
  { 
    id: '310010', 
    name: 'صناعة الأثاث والموبيليا من الخشب', 
    category: 'high', 
    basePrice: '450 ريال',
    requirements: ['نظام سحب غبار الخشب', 'طفايات حريق CO2 وبودرة', 'لوحات منع تدخين'],
    warningNote: 'المكان عالي الخطورة لوجود غبار الخشب والدهانات القابلة للاشتعال.'
  },
  { id: '452011', name: 'اصلاح ماكينات السيارات', category: 'medium', basePrice: '300 ريال' },
  { id: '452012', name: 'اصلاح كهرباء السيارات', category: 'medium', basePrice: '200 ريال' },
  { id: '452021', name: 'تغيير الزيوت وتشحيم السيارات', category: 'medium', basePrice: '250 ريال' },
  { id: '251111', name: 'ورش نجارة الأبواب والشبابيك', category: 'high', basePrice: '400 ريال' },
  { id: '101011', name: 'تشغيل المجازر', category: 'high', basePrice: '500 ريال' },
  { id: '101021', name: 'إنتاج لحوم الدواجن', category: 'medium', basePrice: '300 ريال' },
  { id: '201110', name: 'صناعة المواد الكيميائية الأساسية', category: 'high', basePrice: '1000 ريال', warningNote: 'هذا النشاط يتطلب دراسة هندسية ومعايير عالمية (NFPA).' },

  // --- Warehouses (المستودعات) ---
  { 
    id: '521011', 
    name: 'تشغيل مرافق التخزين لجميع أنواع البضائع', 
    category: 'high', 
    basePrice: '500 ريال',
    requirements: ['نظام رشاشات حريق مائية', 'شبكة خراطيم حريق', 'نظام إنذار مركزي متطور'],
    warningNote: 'تعتمد المتطلبات النهائية على نوع البضائع المخزنة (قابلة للاشتعال أم لا).'
  },
  { id: '521095', name: 'مخازن الأثاث والأخشاب', category: 'high', basePrice: '600 ريال' },
  { id: '521096', name: 'مخازن السيارات', category: 'high', basePrice: '500 ريال' },
  { id: '521092', name: 'مخازن المواد الغذائية', category: 'high', basePrice: '500 ريال' },
  { id: '521099', name: 'مستودعات التبريد (الثلاجات)', category: 'high', basePrice: '600 ريال' },

  // --- Health & Beauty (الصحة والتجميل) ---
  { id: '861011', name: 'المستشفيات العامة', category: 'high', basePrice: 'اتصل بنا', warningNote: 'المستشفيات تتطلب نظام كود حماية (Life Safety Code) ومخارج طوارئ متعددة.' },
  { id: '862063', name: 'المجمعات الطبية العامة', category: 'medium', basePrice: '300 ريال' },
  { id: '477212', name: 'البيع بالتجزئة للأجهزة الطبية', category: 'simple', basePrice: '69 ريال' },
  { id: '960220', name: 'الصالونات الرجالية', category: 'simple', basePrice: '69 ريال' },
  { id: '960210', name: 'الصالونات النسائية', category: 'simple', basePrice: '69 ريال' },
  { id: '931101', name: 'الصالات الرياضية (الجيم)', category: 'medium', basePrice: '250 ريال' },

  // --- Education & Training (التعليم والتدريب) ---
  { id: '851010', name: 'التعليم في مرحلة ما قبل المدرسة (رياض الأطفال)', category: 'high', basePrice: '500 ريال', requirements: ['نظام إنذار صوتي ومرئي', 'أرضيات آمنة ومقاومة للحريق', 'خطة إخلاء معتمدة'] },
  { id: '853010', name: 'مراكز التدريب المهني', category: 'medium', basePrice: '300 ريال' },
  { id: '854110', name: 'التعليم الرياضي والفروسي', category: 'medium', basePrice: '300 ريال' },

  // --- Hospitality & Tourism (الضيافة والسياحة) ---
  { id: '551010', name: 'الفنادق', category: 'high', basePrice: 'اتصل بنا' },
  { id: '551011', name: 'الوحدات السكنية المفروشة', category: 'high', basePrice: '400 ريال' },
  { id: '551030', name: 'الاستراحات وبيوت الشباب', category: 'medium', basePrice: '250 ريال' },

  // --- Services & Offices (الخدمات والمكاتب) ---
  { id: '711013', name: 'أنشطة الاستشارات الهندسية والمعمارية', category: 'simple', basePrice: '69 ريال' },
  { id: '691010', name: 'أنشطة المحاماة والاستشارات القانونية', category: 'simple', basePrice: '69 ريال' },
  { id: '702010', name: 'أنشطة الاستشارات الإدارية', category: 'simple', basePrice: '69 ريال' },
  { id: '432132', name: 'تركيب وصيانة أجهزة ومعدات الإنذار من الحريق', category: 'medium', basePrice: '200 ريال' },
  { id: '432230', name: 'تركيب الادوات الصحية وصيانتها واصلاحها', category: 'simple', basePrice: '69 ريال' },
  { id: '960110', name: 'غسل وكي الملابس (مغاسل)', category: 'medium', basePrice: '150 ريال' },
  { id: '531010', name: 'أنشطة البريد الحكومي', category: 'simple', basePrice: '69 ريال' },
  { id: '532010', name: 'أنشطة البريد الخاص والطرود', category: 'medium', basePrice: '150 ريال' },
  
  // --- Contracting (المقاولات) ---
  { id: '410010', name: 'تشييد المباني السكنية', category: 'medium', basePrice: '250 ريال' },
  { id: '410020', name: 'تشييد المباني غير السكنية', category: 'medium', basePrice: '300 ريال' },
  { id: '432111', name: 'التمديدات الكهربائية', category: 'simple', basePrice: '69 ريال' },
  
  // --- New Additions (ISIC4 Riyadh Standard) ---
  // Agriculture & Livestock
  { id: '011111', name: 'زراعة الحبوب (القمح، الذرة، إلخ)', category: 'simple', basePrice: '69 ريال' },
  { id: '011311', name: 'زراعة الخضروات الورقية والدرنية', category: 'simple', basePrice: '69 ريال' },
  { id: '014111', name: 'تربية المواشي (الأغنام والماعز)', category: 'medium', basePrice: '150 ريال' },
  { id: '014411', name: 'تربية الدواجن لإنتاج البيض', category: 'medium', basePrice: '200 ريال' },

  // Manufacturing & Industrial
  { id: '107920', name: 'صناعة البهارات والتوابل', category: 'medium', basePrice: '150 ريال' },
  { id: '108010', name: 'صناعة الأغذية الحيوانية (الأعلاف)', category: 'high', basePrice: '500 ريال' },
  { id: '131210', name: 'صناعة المنسوجات والسجاد', category: 'high', basePrice: '450 ريال' },
  { id: '181110', name: 'طباعة الصحف والمجلات', category: 'medium', basePrice: '300 ريال' },
  { id: '181120', name: 'طباعة الكتب والخرائط', category: 'medium', basePrice: '200 ريال' },
  { id: '202210', name: 'صناعة الدهانات والورنيشات', category: 'high', basePrice: '600 ريال', warningNote: 'يتطلب أنظمة إطفاء رغوية (Foam Systems) وتخزين آمن للمواد الكيميائية.' },
  { id: '222010', name: 'صناعة المنتجات البلاستيكية', category: 'high', basePrice: '500 ريال' },
  { id: '239410', name: 'صناعة الإسمنت والخرسانة الجاهزة', category: 'high', basePrice: '800 ريال' },
  { id: '251141', name: 'صناعة الهياكل المعدنية', category: 'high', basePrice: '450 ريال' },
  { id: '259310', name: 'صناعة أدوات القطع والأدوات اليدوية', category: 'medium', basePrice: '300 ريال' },
  { id: '310020', name: 'صناعة المراتب والأسرة', category: 'high', basePrice: '400 ريال' },
  { id: '321110', name: 'صناعة الحلي والمجوهرات', category: 'medium', basePrice: '250 ريال', requirements: ['خزائن مؤمنة ضد الحريق', 'نظام إنذار ضد السرقة مرتبط بالأمن'] },

  // Trade & Retail Expansion
  { id: '451010', name: 'بيع السيارات بالتجزئة', category: 'medium', basePrice: '350 ريال' },
  { id: '453010', name: 'بيع قطع غيار السيارات بالتجزئة', category: 'simple', basePrice: '99 ريال' },
  { id: '454010', name: 'بيع الدراجات النارية وقطع غيارها', category: 'simple', basePrice: '99 ريال' },
  { id: '461011', name: 'الوساطة في بيع السلع والخدمات', category: 'simple', basePrice: '69 ريال' },
  { id: '463011', name: 'البيع بالجملة للمنتجات الغذائية المعبأة', category: 'medium', basePrice: '200 ريال' },
  { id: '464111', name: 'البيع بالجملة للمنسوجات والأقمشة', category: 'high', basePrice: '400 ريال' },
  { id: '465111', name: 'البيع بالجملة لأجهزة الحاسوب والبرمجيات', category: 'simple', basePrice: '99 ريال' },
  { id: '472131', name: 'البيع بالتجزئة للحلويات والمكسرات', category: 'simple', basePrice: '69 ريال' },
  { id: '475111', name: 'البيع بالتجزئة للمنسوجات المنزلية والستائر', category: 'simple', basePrice: '99 ريال' },
  { id: '475311', name: 'البيع بالتجزئة للسجاد والبساط', category: 'medium', basePrice: '150 ريال' },
  { id: '475921', name: 'البيع بالتجزئة لأدوات المائدة والمطبخ', category: 'simple', basePrice: '69 ريال' },
  { id: '476411', name: 'البيع بالتجزئة للأجهزة الرياضية وأدوات الصيد', category: 'simple', basePrice: '99 ريال' },
  { id: '477341', name: 'البيع بالتجزئة للأحذية والمصنوعات الجلدية', category: 'simple', basePrice: '69 ريال' },
  { id: '477351', name: 'البيع بالتجزئة للحقائب والأمتعة', category: 'simple', basePrice: '69 ريال' },
  { id: '477362', name: 'البيع بالتجزئة للتحف واللوحات الفنية', category: 'simple', basePrice: '69 ريال' },
  { id: '475211', name: 'البيع بالتجزئة للدهانات والبويا', category: 'medium', basePrice: '150 ريال' },
  { id: '475221', name: 'البيع بالتجزئة للأدوات الصحية', category: 'simple', basePrice: '69 ريال' },
  { id: '475231', name: 'البيع بالتجزئة للأدوات اليدوية والمناشير', category: 'simple', basePrice: '69 ريال' },
  { id: '476111', name: 'البيع بالتجزئة للكتب والمطبوعات', category: 'simple', basePrice: '69 ريال' },
  { id: '476121', name: 'البيع بالتجزئة للقرطاسية والأدوات المكتبية', category: 'simple', basePrice: '69 ريال' },
  { id: '476211', name: 'البيع بالتجزئة للأدوات الرياضية', category: 'simple', basePrice: '69 ريال' },
  { id: '476311', name: 'البيع بالتجزئة للألعاب واللعب', category: 'simple', basePrice: '99 ريال' },
  { id: '477381', name: 'البيع بالتجزئة للزهور والنباتات طبيعية وصناعية', category: 'simple', basePrice: '69 ريال' },
  { id: '477391', name: 'البيع بالتجزئة للحيوانات الأليفة', category: 'simple', basePrice: '99 ريال' },
  { id: '474111', name: 'البيع بالتجزئة لأجهزة الحاسوب وملحقاتها', category: 'simple', basePrice: '69 ريال' },
  { id: '474121', name: 'البيع بالتجزئة للهواتف النقالة', category: 'simple', basePrice: '69 ريال' },

  // Transport & Storage
  { id: '492211', name: 'نقل الركاب بالحافلات داخل المدن', category: 'medium', basePrice: '200 ريال' },
  { id: '492311', name: 'نقل البضائع على الطرق بالشاحنات', category: 'high', basePrice: '400 ريال' },
  { id: '522411', name: 'مناولة البضائع ونقلها', category: 'medium', basePrice: '250 ريال' },
  { id: '522912', name: 'تعبئة وتغليف البضائع وتجهيزها للشحن', category: 'medium', basePrice: '200 ريال' },
  { id: '522131', name: 'مواقف السيارات المدفوعة', category: 'medium', basePrice: '300 ريال' },

  // Information & Communication
  { id: '581110', name: 'نشر الكتب والكتيبات', category: 'simple', basePrice: '69 ريال' },
  { id: '581310', name: 'نشر الصحف والمطبوعات الدورية', category: 'simple', basePrice: '69 ريال' },
  { id: '620110', name: 'تصميم وبرمجة البرمجيات الخاصة', category: 'simple', basePrice: '69 ريال' },
  { id: '620210', name: 'الاستشارات في مجال تكنولوجيا المعلومات', category: 'simple', basePrice: '69 ريال' },
  { id: '631110', name: 'استضافة المواقع ومعالجة البيانات', category: 'medium', basePrice: '200 ريال', requirements: ['نظام إطفاء غازي لغرف السيرفرات (FM200)'] },

  // Finance & Real Estate
  { id: '641911', name: 'الخدمات المصرفية (البنوك)', category: 'high', basePrice: 'اتصل بنا' },
  { id: '662211', name: 'وكلاء ووسطاء التأمين', category: 'simple', basePrice: '69 ريال' },
  { id: '681010', name: 'بيع وشراء العقارات وتطويرها', category: 'simple', basePrice: '99 ريال' },
  { id: '682010', name: 'تأجير العقارات المملوكة أو المستأجرة', category: 'simple', basePrice: '99 ريال' },

  // Professional & Technical
  { id: '711011', name: 'مكاتب الاستشارات الهندسية', category: 'simple', basePrice: '69 ريال' },
  { id: '711021', name: 'مكاتب العمارة والتخطيط', category: 'simple', basePrice: '69 ريال' },
  { id: '712010', name: 'الاختبارات والفحوصات التقنية', category: 'medium', basePrice: '250 ريال' },
  { id: '731010', name: 'وكالات الدعاية والإعلان', category: 'simple', basePrice: '69 ريال' },
  { id: '741010', name: 'أنشطة التصميم المتخصص (ديكور، جرافيك)', category: 'simple', basePrice: '69 ريال' },
  { id: '742010', name: 'أنشطة التصوير الفوتوغرافي', category: 'simple', basePrice: '150 ريال' },
  { id: '750010', name: 'الأنشطة البيطرية', category: 'medium', basePrice: '200 ريال' },

  // Admin & Support
  { id: '771010', name: 'تأجير السيارات الصغيرة والمتوسطة', category: 'medium', basePrice: '250 ريال' },
  { id: '781010', name: 'وكالات الاستقدام والتوظيف', category: 'simple', basePrice: '69 ريال' },
  { id: '791110', name: 'وكالات السفر والسياحة', category: 'simple', basePrice: '69 ريال' },
  { id: '801010', name: 'خدمات الحراسات الأمنية والتحقيق', category: 'medium', basePrice: '200 ريال' },
  { id: '812110', name: 'خدمات التنظيف العام للمباني', category: 'simple', basePrice: '69 ريال' },
  { id: '822010', name: 'مراكز الاتصال (كول سنتر)', category: 'medium', basePrice: '200 ريال' },
  { id: '823010', name: 'تنظيم المعارض والمؤتمرات والندوات', category: 'high', basePrice: '500 ريال' },

  // Education & Health Expansion
  { id: '852110', name: 'التعليم الابتدائي والمتوسط في المدارس الأهلية', category: 'high', basePrice: '600 ريال' },
  { id: '852210', name: 'التعليم الثانوي الفني والمهني', category: 'high', basePrice: '600 ريال' },
  { id: '862011', name: 'عيادات الأسنان الأهلية', category: 'medium', basePrice: '300 ريال' },
  { id: '869011', name: 'مختبرات التحاليل الطبية وحفظ الدم', category: 'high', basePrice: '400 ريال' },
  { id: '871010', name: 'دور الرعاية التأهيلية للمسنين', category: 'high', basePrice: '500 ريال' },

  // Arts & Entertainment
  { id: '900010', name: 'الأنشطة الإبداعية والفنون والترفيه', category: 'medium', basePrice: '250 ريال' },
  { id: '910210', name: 'أنشطة المتاحف وتشغيل المواقع التاريخية', category: 'medium', basePrice: '300 ريال' },
  { id: '920010', name: 'أنشطة المقامرة والمراهنة (مراكز ترفيهية مرخصة)', category: 'high', basePrice: '500 ريال' },
  { id: '932110', name: 'تشغيل مدن الملاهي والمنتزهات الترفيهية', category: 'high', basePrice: '1000 ريال' },

  // Personal Services
  { id: '960911', name: 'مغاسل السجاد والمفروشات', category: 'medium', basePrice: '200 ريال' },
  { id: '960912', name: 'مغاسل الفرش والكنب والستائر', category: 'medium', basePrice: '200 ريال' },
  { id: '960921', name: 'خدمات العناية بالحيوانات الأليفة', category: 'simple', basePrice: '99 ريال' },
  { id: '960310', name: 'أنشطة الجنازات والخدمات المتصلة بها', category: 'medium', basePrice: '300 ريال' },

  // Industrial & Repair
  { id: '331210', name: 'إصلاح الآلات والمعدات الميكانيكية', category: 'high', basePrice: '400 ريال' },
  { id: '331310', name: 'إصلاح المعدات الإلكترونية والضوئية', category: 'medium', basePrice: '250 ريال' },
  { id: '331410', name: 'إصلاح المعدات الكهربائية', category: 'medium', basePrice: '250 ريال' },
  { id: '332010', name: 'تركيب الآلات والمعدات الصناعية', category: 'high', basePrice: '500 ريال' },

  // Utilities
  { id: '351010', name: 'توليد الطاقة الكهربائية', category: 'high', basePrice: '1500 ريال' },
  { id: '360010', name: 'جمع وتطوير ونقل وتوزيع المياه', category: 'medium', basePrice: '400 ريال' },
  { id: '381110', name: 'جمع النفايات غير الخطرة', category: 'medium', basePrice: '400 ريال' },
  { id: '381210', name: 'جمع النفايات الخطرة', category: 'high', basePrice: '1000 ريال' },
  { id: '390010', name: 'أنشطة المعالجة وخدمات إدارة النفايات الأخرى', category: 'high', basePrice: '800 ريال' },

  // Construction Specialties
  { id: '431110', name: 'هدم وإزالة المباني والمنشآت', category: 'high', basePrice: '600 ريال' },
  { id: '432112', name: 'تمديد أسلاك الاتصالات وشبكات الحاسب', category: 'simple', basePrice: '99 ريال' },
  { id: '432210', name: 'تمديد أنابيب الغاز الطبيعي وصيانتها', category: 'high', basePrice: '500 ريال' },
  { id: '432240', name: 'تركيب أنظمة التكييف والتدفئة والتهوية', category: 'medium', basePrice: '250 ريال' },
  { id: '433011', name: 'أعمال اللياسة والدهانات للمباني', category: 'simple', basePrice: '69 ريال' },
  { id: '433021', name: 'أعمال تركيب السيراميك والرخام والبلاط', category: 'simple', basePrice: '69 ريال' },
  { id: '433031', name: 'أعمال النجارة والتركيبات الخشبية للمباني', category: 'medium', basePrice: '150 ريال' },
  { id: '439011', name: 'أعمال العزل المائي والحراري والصوتي', category: 'medium', basePrice: '250 ريال' },

  // Additional Trade
  { id: '462011', name: 'البيع بالجملة للمنتجات الزراعية الخام', category: 'medium', basePrice: '300 ريال' },
  { id: '463021', name: 'البيع بالجملة لمنتجات الألبان والبيض', category: 'medium', basePrice: '250 ريال' },
  { id: '464911', name: 'البيع بالجملة للأدوات المنزلية وأدوات المائدة', category: 'medium', basePrice: '200 ريال' },
  { id: '465211', name: 'البيع بالجملة للمعدات والأجهزة الإلكترونية', category: 'medium', basePrice: '250 ريال' },
  { id: '466111', name: 'البيع بالجملة للوقود الصلب والسائل والغازي', category: 'high', basePrice: '1000 ريال' },
  { id: '466311', name: 'البيع بالجملة للخشب والفلين ومواد البناء', category: 'high', basePrice: '500 ريال' },
  { id: '474211', name: 'البيع بالتجزئة للأجهزة السمعية والبصرية', category: 'simple', basePrice: '99 ريال' },
  { id: '475931', name: 'البيع بالتجزئة لأدوات الإنارة والأدوات الكهربائية', category: 'simple', basePrice: '99 ريال' },
  { id: '477382', name: 'البيع بالتجزئة للأسمدة والمبيدات الزراعية', category: 'medium', basePrice: '250 ريال' },
  { id: '479110', name: 'البيع بالتجزئة عبر الإنترنت (المتاجر الإلكترونية)', category: 'simple', basePrice: '69 ريال' },

  // --- Massive Expansion 2 (Hospitality & Industrial) ---
  { id: '551012', name: 'الفنادق التراثية', category: 'high', basePrice: 'اتصل بنا' },
  { id: '551013', name: 'المنتجعات السياحية', category: 'high', basePrice: 'اتصل بنا' },
  { id: '551040', name: 'المخيمات السياحية', category: 'medium', basePrice: '300 ريال' },
  { id: '551050', name: 'نزل الشقق الفندقية', category: 'high', basePrice: '400 ريال' },
  { id: '562110', name: 'تموين الحفلات والمناسبات (الإعاشة المستمرة)', category: 'high', basePrice: '500 ريال' },
  { id: '562910', name: 'أنشطة خدمات الأطعمة الأخرى (الكافتيرات داخل المدارس)', category: 'medium', basePrice: '200 ريال' },
  
  // Industrial - Food
  { id: '101030', name: 'تجهيز وحفظ اللحوم ومنتجاتها', category: 'high', basePrice: '600 ريال' },
  { id: '102010', name: 'تجهيز وحفظ الأسماك والمنتجات البحرية', category: 'high', basePrice: '600 ريال' },
  { id: '103010', name: 'تجهيز وحفظ الفواكه والخضروات', category: 'high', basePrice: '500 ريال' },
  { id: '104010', name: 'صنع الزيوت والدهون النباتية والحيوانية', category: 'high', basePrice: '700 ريال' },
  { id: '105010', name: 'صنع منتجات الألبان', category: 'high', basePrice: '600 ريال' },
  { id: '106110', name: 'صنع منتجات طواحين الغلال (الدقيق)', category: 'high', basePrice: '500 ريال' },
  { id: '106120', name: 'صنع النشا ومنتجاته', category: 'high', basePrice: '500 ريال' },
  { id: '107210', name: 'صنع البسكويت والمعجنات المحفوظة', category: 'medium', basePrice: '300 ريال' },
  { id: '107410', name: 'صنع المكرونة والشعيرية والكسكسي', category: 'medium', basePrice: '250 ريال' },
  { id: '107930', name: 'صنع الأغذية المحضرة المتنوعة (أغذية الأطفال)', category: 'high', basePrice: '600 ريال' },
  
  // Industrial - Beverages
  { id: '110410', name: 'صنع المشروبات الغازية والمياه المعدنية', category: 'high', basePrice: '700 ريال' },
  { id: '110420', name: 'صنع عصائر الفاكهة والخضروات', category: 'high', basePrice: '500 ريال' },
  
  // Industrial - Materials
  { id: '170110', name: 'صنع عجينة الورق والورق والمقوى', category: 'high', basePrice: '600 ريال' },
  { id: '170210', name: 'صنع الورق والكرتون المموج والعبوات', category: 'high', basePrice: '500 ريال' },
  { id: '170910', name: 'صنع المنتجات الورقية الأخرى (المناديل المعطرة)', category: 'medium', basePrice: '300 ريال' },
  { id: '201120', name: 'صنع الغازات الصناعية والطبية (الأكسجين، النيتروجين)', category: 'high', basePrice: '1500 ريال', warningNote: 'عالي الخطورة - يتطلب أنظمة تبريد وتأمين انفجار.' },
  { id: '201210', name: 'صنع الأسمدة والمركبات النيتروجينية', category: 'high', basePrice: '1000 ريال' },
  { id: '202110', name: 'صنع المبيدات الحشرية والمنتجات الكيميائية الزراعية', category: 'high', basePrice: '1000 ريال' },
  { id: '202310', name: 'صنع الصابون والمنظفات ومستحضرات التجميل', category: 'high', basePrice: '500 ريال' },
  { id: '210010', name: 'صناعة الأدوية والمواد الكيميائية الطبية', category: 'high', basePrice: '1200 ريال' },
  
  // Metal & Machinery
  { id: '241010', name: 'صنع الحديد والصلب الأساسي', category: 'high', basePrice: '2000 ريال' },
  { id: '242010', name: 'صنع المنتجات الثمينة والمعادن غير الحديدية', category: 'high', basePrice: '1200 ريال' },
  { id: '251120', name: 'صنع الخزانات والصهاريج والأوعية المعدنية', category: 'high', basePrice: '600 ريال' },
  { id: '259110', name: 'طرق وكبس وسبك المعادن', category: 'high', basePrice: '800 ريال' },
  { id: '259210', name: 'معالجة وطلاء المعادن بالكهرباء', category: 'high', basePrice: '700 ريال' },
  { id: '261010', name: 'صنع المكونات واللوحات الإلكترونية', category: 'medium', basePrice: '400 ريال' },
  { id: '262010', name: 'صنع أجهزة الحاسوب والمعدات الطرفية', category: 'medium', basePrice: '300 ريال' },
  { id: '263010', name: 'صنع أجهزة الاتصالات (الراديو والتلفزيون)', category: 'medium', basePrice: '300 ريال' },
  { id: '271010', name: 'صنع المحركات والمحولات والموزعات الكهربائية', category: 'high', basePrice: '800 ريال' },
  { id: '272010', name: 'صنع البطاريات والمراكم الكهربائية', category: 'high', basePrice: '600 ريال' },
  { id: '273310', name: 'صنع أجهزة التوصيل والأسلاك الكهربائية', category: 'high', basePrice: '500 ريال' },
  { id: '281310', name: 'صنع المضخات والضواغط والصمامات', category: 'high', basePrice: '600 ريال' },
  { id: '281410', name: 'صنع المحامل والتروس وأجهزة النقل', category: 'medium', basePrice: '400 ريال' },
  { id: '291010', name: 'صنع المركبات ذات المحركات', category: 'high', basePrice: '2500 ريال' },
  { id: '309110', name: 'صنع الدراجات النارية', category: 'high', basePrice: '600 ريال' },
  
  // Trade - Bulk
  { id: '466210', name: 'البيع بالجملة للمعادن والخامات المعدنية', category: 'high', basePrice: '600 ريال' },
  { id: '466320', name: 'البيع بالجملة للدهانات والورنيشات', category: 'high', basePrice: '500 ريال' },
  { id: '466910', name: 'البيع بالجملة للنفايات والخردة', category: 'medium', basePrice: '400 ريال' },
  { id: '469010', name: 'البيع بالجملة غير المتخصص', category: 'medium', basePrice: '300 ريال' },
  
  // Retail - Specialized
  { id: '477113', name: 'البيع بالتجزئة لملابس الأطفال', category: 'simple', basePrice: '69 ريال' },
  { id: '477114', name: 'البيع بالتجزئة لملابس التريكو والأصواف', category: 'simple', basePrice: '69 ريال' },
  { id: '477115', name: 'البيع بالتجزئة للأقمشة المنسوجة', category: 'simple', basePrice: '99 ريال' },
  { id: '477213', name: 'البيع بالتجزئة للنظارات والعدسات', category: 'simple', basePrice: '69 ريال' },
  { id: '477383', name: 'البيع بالتجزئة لمعدات إطفاء الحريق', category: 'simple', basePrice: '69 ريال' },
  { id: '477384', name: 'البيع بالتجزئة للأجهزة الأمنية', category: 'simple', basePrice: '99 ريال' },
  { id: '477385', name: 'البيع بالتجزئة لمستلزمات الصيد والفروسية', category: 'medium', basePrice: '150 ريال' },
  { id: '478110', name: 'البيع بالتجزئة عبر الأكشاك والأسواق (أغذية ومشروبات)', category: 'simple', basePrice: '69 ريال' },
  { id: '478210', name: 'البيع بالتجزئة عبر الأكشاك والأسواق (منسوجات وملبوسات)', category: 'simple', basePrice: '69 ريال' },

  // Specialized Transport
  { id: '501110', name: 'نقل الركاب بحراً وعبر المحيطات', category: 'high', basePrice: 'اتصل بنا' },
  { id: '511010', name: 'نقل الركاب جوًا بالخطوط المنتظمة', category: 'high', basePrice: 'اتصل بنا' },
  { id: '512010', name: 'نقل البضائع جوًا', category: 'high', basePrice: 'اتصل بنا' },
  { id: '521012', name: 'تخزين الغلال والصوامع', category: 'high', basePrice: '800 ريال' },
  { id: '522110', name: 'تشغيل مرافق النقل البري (محطات الركاب)', category: 'high', basePrice: '600 ريال' },
  
  // Services
  { id: '611010', name: 'أنشطة الاتصالات السلكية', category: 'medium', basePrice: '300 ريال' },
  { id: '612010', name: 'أنشطة الاتصالات اللاسلكية', category: 'medium', basePrice: '300 ريال' },
  { id: '631120', name: 'تشغيل محركات البحث على الإنترنت', category: 'simple', basePrice: '99 ريال' },
  { id: '639110', name: 'أنشطة وكالات الأنباء', category: 'simple', basePrice: '69 ريال' },
  { id: '661110', name: 'إدارة الأسواق المالية', category: 'high', basePrice: 'اتصل بنا' },
  { id: '692010', name: 'أنشطة المحاسبة والمراجعة ومسك الدفاتر', category: 'simple', basePrice: '69 ريال' },
  { id: '701010', name: 'أنشطة المكاتب الرئيسية (إدارة الشركات)', category: 'simple', basePrice: '99 ريال' },
  { id: '711012', name: 'المكاتب الهندسية (ميكانيكا وكهرباء)', category: 'simple', basePrice: '69 ريال' },
  { id: '721010', name: 'البحث والتطوير التجريبي في العلوم الطبيعية', category: 'high', basePrice: '500 ريال' },
  { id: '732010', name: 'استطلاع الرأي العام وبحوث السوق', category: 'simple', basePrice: '69 ريال' },
  { id: '772110', name: 'تأجير الأدوات الرياضية والترفيهية', category: 'medium', basePrice: '150 ريال' },
  { id: '773010', name: 'تأجير الآلات والمعدات المكتبية (بما في ذلك الحواسيب)', category: 'simple', basePrice: '99 ريال' },
  { id: '811010', name: 'أنشطة خدمات الدعم المشترك للمنشآت', category: 'simple', basePrice: '99 ريال' },
  { id: '853020', name: 'التعليم التقني والمهني فوق الثانوي', category: 'high', basePrice: '500 ريال' },
  { id: '854910', name: 'تعليم الفنون واللغات والموسيقى', category: 'medium', basePrice: '200 ريال' },
  { id: '881010', name: 'أنشطة العمل الاجتماعي لكبار السن والمعاقين', category: 'medium', basePrice: '300 ريال' },
  { id: '951110', name: 'إصلاح أجهزة الحاسوب والمعدات الطرفية', category: 'simple', basePrice: '69 ريال' },
  { id: '952110', name: 'إصلاح الأجهزة الإلكترونية الاستهلاكية', category: 'simple', basePrice: '69 ريال' },
  { id: '952210', name: 'إصلاح الأجهزة المنزلية وأدوات الحدائق', category: 'simple', basePrice: '69 ريال' },
  { id: '952310', name: 'إصلاح الأحذية والمصنوعات الجلدية', category: 'simple', basePrice: '69 ريال' },
  { id: '952410', name: 'إصلاح الأثاث والمفروشات المنزلية', category: 'medium', basePrice: '150 ريال' },
  { id: '960230', name: 'مراكز التجميل والعناية بالبشرة', category: 'simple', basePrice: '99 ريال' },
  { id: '960240', name: 'أنشطة الحمامات والمساج وغير ذلك', category: 'medium', basePrice: '250 ريال' },
];
