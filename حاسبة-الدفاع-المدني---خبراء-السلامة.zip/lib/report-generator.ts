import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export async function generatePDF(elementId: string, fileName: string) {
  const element = document.getElementById(elementId);
  if (!element) return;

  try {
    // Hide buttons during capture
    const buttons = element.querySelectorAll('button, .print-hidden');
    buttons.forEach((btn: any) => btn.style.visibility = 'hidden');

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    // Re-show buttons
    buttons.forEach((btn: any) => btn.style.visibility = 'visible');

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'px',
      format: [canvas.width / 2, canvas.height / 2]
    });

    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`${fileName}.pdf`);
  } catch (error) {
    console.error('Error generating PDF:', error);
  }
}

export function formatWhatsAppMessage(title: string, data: any) {
  let message = `*${title}*\n\n`;
  message += `النشاط: ${data.activity}\n`;
  if (data.area) message += `المساحة: ${data.area} م²\n`;
  if (data.hazard) message += `مستوى الخطورة: ${data.hazard}\n`;
  if (data.result) message += `النتيجة: ${data.result}\n`;
  message += `\nأرغب في الحصول على استشارة فنية بخصوص هذا التقرير.`;
  
  return encodeURIComponent(message);
}
