import { BuildingType, CalculationInputs, CalculationResult, HazardLevel, Requirement } from './types';

export const calculateRequirements = (inputs: CalculationInputs): CalculationResult => {
  const { type, area, floors, hazard, hasBasement, numRooms, numSections } = inputs;
  const requirements: Requirement[] = [];

  // 1. Fire Extinguishers (طفاية حريق)
  // Usually 1 for every 100 sqm for low hazard, more for high.
  let extCount = Math.ceil(area / 100);
  if (hazard === HazardLevel.MEDIUM) extCount = Math.ceil(area / 75);
  if (hazard === HazardLevel.HIGH || type === BuildingType.WAREHOUSE) extCount = Math.ceil(area / 50);
  
  // Add adjustment for complex buildings
  if (numRooms && numRooms > 5) extCount += Math.floor(numRooms / 5);
  if (numSections && numSections > 1) extCount += numSections * 2;
  
  requirements.push({
    id: 'extinguisher',
    nameAr: 'طفاية حريق (بودرة 6 كجم)',
    nameEn: 'Fire Extinguisher (6kg Powder)',
    quantity: Math.max(1, extCount),
    unitAr: 'حبة',
    unitEn: 'Units',
  });

  // 2. Smoke Detectors (كاشف دخان)
  let detectorCount = Math.ceil(area / 40); // 1 per 40sqm approx
  if (numRooms) detectorCount = Math.max(detectorCount, numRooms);
  
  requirements.push({
    id: 'smoke_detector',
    nameAr: 'كاشف دخان لاسلكي/معنون',
    nameEn: 'Smoke Detector',
    quantity: detectorCount,
    unitAr: 'حبة',
    unitEn: 'Units',
  });

  // 3. Central Alarm Control Panel (لوحة تحكم بالحريق)
  if (area > 100 || floors > 0) {
    requirements.push({
      id: 'alarm_panel',
      nameAr: 'لوحة تحكم إنذار حريق',
      nameEn: 'Fire Alarm Control Panel',
      quantity: 1,
      unitAr: 'جهاز',
      unitEn: 'Device',
    });
  }

  // 4. Exit Signs (لوحة خروج طوارئ)
  const exitSigns = Math.max(1, Math.ceil(area / 200) + (floors > 0 ? floors : 0));
  requirements.push({
    id: 'exit_sign',
    nameAr: 'لوحة مخارج الطوارئ (تضيء في الظلام)',
    nameEn: 'Emergency Exit Sign',
    quantity: exitSigns,
    unitAr: 'حبة',
    unitEn: 'Units',
  });

  // 5. Fire Hose Reel (صندوق حريق) - mandatory for certain areas
  if (area > 200 || type === BuildingType.WAREHOUSE) {
    const hoseCount = Math.ceil(area / 300) * (floors > 0 ? floors : 1);
    requirements.push({
      id: 'hose_reel',
      nameAr: 'صندوق حريق (بكرة خرطوم)',
      nameEn: 'Fire Hose Reel',
      quantity: Math.max(1, hoseCount),
      unitAr: 'صندوق',
      unitEn: 'Box',
    });
  }

  // 6. Sprinklers (نظام مرشات) - mostly for warehouses or high towers
  if (type === BuildingType.WAREHOUSE && area > 500) {
    requirements.push({
      id: 'sprinklers',
      nameAr: 'نظام رشاشات حريق أوتوماتيكي',
      nameEn: 'Automatic Sprinkler System',
      quantity: 1,
      unitAr: 'نظام متكامل',
      unitEn: 'Full System',
      noteAr: 'يغطي مساحة المستودع بالكامل',
    });
  }

  // Cost calculation (Estimates in SAR)
  let totalCost = 0;
  
  requirements.forEach(req => {
      const itemCosts: Record<string, number> = {
          'extinguisher': 120, // max 150
          'smoke_detector': 90, // max 100 with install
          'alarm_panel': 1200,
          'exit_sign': 80, // max 100
          'hose_reel': 800,
          'sprinklers': 8500,
      };
      
      const itemCost = itemCosts[req.id] || 100;
      totalCost += itemCost * req.quantity;
  });

  // Minor overhead for cables and basic installation
  totalCost *= 1.15;
  
  if (hazard === HazardLevel.MEDIUM) totalCost *= 1.1;
  if (hazard === HazardLevel.HIGH) totalCost *= 1.3;
  if (floors > 1) totalCost *= (1 + (floors - 1) * 0.05);

  return {
    requirements,
    estimatedCostRange: {
      min: Math.round(totalCost * 0.9),
      max: Math.round(totalCost * 1.1),
    },
    processingTimeDays: type === BuildingType.WAREHOUSE ? 14 : 7,
  };
};
