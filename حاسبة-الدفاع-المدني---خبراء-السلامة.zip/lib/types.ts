import React from 'react';

export enum BuildingType {
  WAREHOUSE = 'warehouse',
  RETAIL = 'retail',
  BUILDING = 'building',
  APARTMENT = 'apartment',
  OFFICE = 'office',
  RESTAURANT = 'restaurant',
  FACTORY = 'factory',
}

export enum HazardLevel {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
}

export interface CalculationInputs {
  type: BuildingType;
  area: number;
  floors: number;
  hazard: HazardLevel;
  hasBasement: boolean;
  numRooms?: number;
  numSections?: number;
  phone?: string;
}

export interface Requirement {
  id: string;
  nameAr: string;
  nameEn: string;
  quantity: number;
  unitAr: string;
  unitEn: string;
  noteAr?: string;
  noteEn?: string;
}

export interface CalculationResult {
  requirements: Requirement[];
  estimatedCostRange: {
    min: number;
    max: number;
  };
  processingTimeDays: number;
}
