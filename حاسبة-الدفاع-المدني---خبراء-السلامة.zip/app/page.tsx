// GitHub Sync Trigger: 2026-05-05 11:18 AM
'use client';

import React, { useState } from 'react';
import CalculatorApp from '@/components/CalculatorApp';
import SafetyCertificateCheck from '@/components/SafetyCertificateCheck';
import { motion, AnimatePresence } from 'motion/react';
import { Calculator, ShieldCheck, ShoppingBag, Facebook, Twitter, Instagram } from 'lucide-react';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import logoPic from '../public/logo.png';

export default function Home() {
  const [activeTool, setActiveTool] = useState<'calculator' | 'certificate'>('calculator');

  return (
    <main className="flex flex-col relative" dir="rtl">
      {/* Dynamic Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-orange-100/30 blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-blue-50/40 blur-[120px]" />
        <div 
          className="absolute inset-0 opacity-[0.03]" 
          style={{ backgroundImage: 'radial-gradient(#1e293b 1px, transparent 1px)', backgroundSize: '40px 40px' }} 
        />
      </div>

      <div className="relative z-10 flex-grow flex flex-col py-4 md:py-8 px-4 max-w-5xl mx-auto w-full">
        {/* Shared Header */}
        <header className="flex flex-col md:flex-row justify-between items-center mb-4 md:mb-6 gap-4 bg-white p-3 md:p-5 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex flex-col md:flex-row items-center gap-4 text-center md:text-start">
             <div className="p-1.5 bg-slate-50 rounded-xl flex-shrink-0 w-12 h-12 md:w-16 md:h-16 flex items-center justify-center">
               <Image 
                 src={logoPic} 
                 alt="مؤسسة خبراء السلامة" 
                 width={48} 
                 height={48} 
                 className="object-contain" 
                 priority
                 referrerPolicy="no-referrer"
               />
             </div>
             <div className="flex flex-col">
               <h1 className="text-lg md:text-xl font-bold text-slate-800 tracking-tight">مؤسسة خبراء السلامة</h1>
               <span className="text-[10px] md:text-xs text-slate-500 font-medium">مقاولات عامة</span>
             </div>
          </div>
          <div className="flex flex-wrap items-center justify-center md:justify-end gap-3">
            <div className="flex items-center gap-2 px-2 py-1 bg-slate-50 rounded-xl">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="p-2 text-slate-400 hover:text-blue-600 transition-colors">
                <Facebook size={18} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-2 text-slate-400 hover:text-pink-600 transition-colors">
                <Instagram size={18} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="p-2 text-slate-400 hover:text-black transition-colors">
                <Twitter size={18} />
              </a>
            </div>
            
            <a 
              href="https://safetyexperts-sa.com/ar" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="group relative flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-xl text-[10px] md:text-sm font-bold transition-all hover:bg-orange-700 overflow-hidden"
            >
              <motion.div 
                className="absolute inset-0 bg-white/20 pointer-events-none"
                animate={{ opacity: [0.1, 0.4, 0.1] }}
                transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
              />
              <ShoppingBag size={14} className="md:w-4 md:h-4" />
              زيارة المتجر
            </a>
          </div>
        </header>

        {/* Navigation Tabs */}
        <div className="flex justify-center mb-6 md:mb-10">
          <div className="bg-white p-1 rounded-2xl shadow-sm border border-slate-100 flex gap-1 h-12 md:h-14 items-center">
            <button
              onClick={() => setActiveTool('calculator')}
              className={cn(
                "flex items-center gap-2 px-4 md:px-6 h-full rounded-xl text-xs md:text-sm font-bold transition-all",
                activeTool === 'calculator' 
                  ? "bg-orange-600 text-white shadow-md shadow-orange-100" 
                  : "text-slate-500 hover:bg-slate-50"
              )}
            >
              <Calculator size={14} className="md:w-4 md:h-4" />
              حاسبة الاحتياجات
            </button>
            <button
              onClick={() => setActiveTool('certificate')}
              className={cn(
                "flex items-center gap-2 px-4 md:px-6 h-full rounded-xl text-xs md:text-sm font-bold transition-all",
                activeTool === 'certificate' 
                  ? "bg-blue-600 text-white shadow-md shadow-blue-100" 
                  : "text-slate-500 hover:bg-slate-50"
              )}
            >
              <ShieldCheck size={14} className="md:w-4 md:h-4" />
              شهادة السلامة
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {activeTool === 'calculator' ? (
            <motion.div
              key="calc"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3 }}
            >
              <CalculatorApp onNavigateToCertificate={() => setActiveTool('certificate')} />
            </motion.div>
          ) : (
            <motion.div
              key="cert"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3 }}
            >
              <SafetyCertificateCheck />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <footer className="relative z-10 py-6 text-center text-xs text-slate-400 pb-[calc(1.5rem+env(safe-area-inset-bottom))]">
        جميع الحقوق محفوظة لـ مؤسسة خبراء السلامة لأنظمة السلامة © {new Date().getFullYear()}
      </footer>
    </main>
  );
}
