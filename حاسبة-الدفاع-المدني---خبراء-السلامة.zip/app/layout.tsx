// Last sync trigger: 2026-05-05 11:20 AM - WhatsApp and Icons update
import type {Metadata} from 'next';
import { IBM_Plex_Sans_Arabic } from 'next/font/google';
import { MessageCircle } from 'lucide-react';
import './globals.css';

const ibmPlexSansArabic = IBM_Plex_Sans_Arabic({
  subsets: ['arabic', 'latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-ibm-plex-sans-arabic',
});

export const metadata: Metadata = {
  title: 'حاسبة الدفاع المدني | إصدار فورية وشهادات سلامة معتمدة',
  description: 'أداة ذكية لحساب متطلبات الدفاع المدني، إصدار شهادات السلامة الفورية، وإعداد التقارير الفنية والهندسية المعتمدة لجميع الأنشطة التجارية في المملكة.',
  icons: {
    icon: '/logo.png',
    shortcut: '/logo.png',
    apple: '/logo.png',
  },
  openGraph: {
    title: 'حاسبة الدفاع المدني | إصدار فورية وشهادات سلامة معتمدة',
    description: 'تحقق من متطلبات سلامة لمنشأتك وأصدر التقارير الهندسية والشهادات الفورية بسهولة عبر مؤسسة خبراء السلامة.',
    images: [
      {
        url: '/logo.png',
        width: 800,
        height: 600,
        alt: 'حاسبة الدفاع المدني - مؤسسة خبراء السلامة',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'حاسبة الدفاع المدني | إصدار فورية وشهادات سلامة معتمدة',
    description: 'أداة ذكية لحساب متطلبات الدفاع المدني وإصدار الشهادات والتقارير الفنية.',
    images: ['/logo.png'],
  },
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'حاسبة السلامة',
  },
  formatDetection: {
    telephone: false,
  },
};

export const viewport = {
  themeColor: '#0f172a',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="ar" dir="rtl" className={`${ibmPlexSansArabic.variable} h-full`}>
      <body className="font-sans antialiased h-full overflow-x-hidden bg-slate-50" suppressHydrationWarning>
        {children}
        
        {/* Floating WhatsApp Support Button */}
        <a 
          href="https://wa.me/966558085879" 
          target="_blank" 
          rel="noopener noreferrer"
          className="fixed bottom-20 left-6 z-[60] bg-green-600 text-white p-3 md:p-4 rounded-full shadow-2xl hover:bg-green-700 transition-all hover:scale-110 group active:scale-95 flex items-center gap-2 animate-bounce hover:animate-none"
          title="تواصل مع خبير السلامة"
        >
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 font-bold whitespace-nowrap text-sm">
            تحدث مع خبير
          </span>
          <MessageCircle size={28} />
        </a>
      </body>
    </html>
  );
}
