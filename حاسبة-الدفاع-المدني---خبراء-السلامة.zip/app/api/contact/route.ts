
import { NextResponse } from 'next/server';
import { Resend } from 'resend';

const getResend = () => {
  const key = process.env.RESEND_API_KEY;
  if (!key) {
    console.error('RESEND_API_KEY is missing. Emails will not be sent.');
    return null;
  }
  return new Resend(key);
};

export async function POST(req: Request) {
  try {
    const resend = getResend();
    if (!resend) {
      return NextResponse.json({ success: false, error: 'Email service is not configured' }, { status: 503 });
    }
    const body = await req.json();
    const { type, action, inputs } = body;

    const emailContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; padding: 20px; border-radius: 10px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <img src="https://ais-pre-rm6l77goxoo7yzziut2hxg-77012022222.europe-west2.run.app/logo.png" alt="Logo" style="max-width: 100px; height: auto;" />
        </div>
        <h2 style="color: #f97316; border-bottom: 2px solid #f97316; padding-bottom: 10px;">إشعار جديد من حاسبة الدفاع المدني</h2>
        <p style="font-size: 16px; color: #334155;">قام المستخدم بطلب إجراء: <strong>${action}</strong></p>
        <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
          <tr><td style="padding: 10px; border-bottom: 1px solid #f1f5f9;">نوع المنشأة:</td><td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold;">${inputs.type}</td></tr>
          <tr><td style="padding: 10px; border-bottom: 1px solid #f1f5f9;">المساحة:</td><td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold;">${inputs.area} م²</td></tr>
          <tr><td style="padding: 10px; border-bottom: 1px solid #f1f5f9;">عدد الطوابق:</td><td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold;">${inputs.floors}</td></tr>
          <tr><td style="padding: 10px; border-bottom: 1px solid #f1f5f9;">مستوى الخطورة:</td><td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold;">${inputs.hazard}</td></tr>
          <tr><td style="padding: 10px; border-bottom: 1px solid #f1f5f9;">الغرف/الأقسام:</td><td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold;">${inputs.numRooms || 0} / ${inputs.numSections || 0}</td></tr>
          <tr><td style="padding: 10px; border-bottom: 1px solid #f1f5f9;">رقم الهاتف:</td><td style="padding: 10px; border-bottom: 1px solid #f1f5f9; font-weight: bold;">${inputs.phone || 'غير مدخل'}</td></tr>
        </table>
        <p style="margin-top: 20px; color: #64748b; font-size: 14px;">يرجى التواصل مع المستخدم في أقرب وقت.</p>
      </div>
    `;

    await resend.emails.send({
      from: 'onboarding@resend.dev', // Use a verified domain if available
      to: 'amanrental2020@gmail.com',
      subject: `طلب جديد: ${action}`,
      html: emailContent,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Email error:', error);
    return NextResponse.json({ success: false, error: 'Failed to send email' }, { status: 500 });
  }
}
