'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Building2, 
  Warehouse, 
  Store, 
  Home, 
  Briefcase, 
  Utensils, 
  ChevronLeft, 
  ChevronRight, 
  ChevronDown,
  FileCheck,
  CheckCircle2, 
  AlertTriangle,
  Info,
  ArrowRight,
  Calculator as CalcIcon,
  ShieldCheck,
  FileText,
  Phone,
  MessageCircle,
  ShoppingBag,
  Download,
  Share2
} from 'lucide-react';
import { BuildingType, CalculationInputs, HazardLevel, CalculationResult } from '@/lib/types';
import { calculateRequirements } from '@/lib/calculator-logic';
import { cn } from '@/lib/utils';
import { generatePDF, formatWhatsAppMessage } from '@/lib/report-generator';

const bannerMessages = [
  { ar: 'زر متجرنا الإلكتروني', en: 'Visit our online store', link: 'https://safetyexperts-sa.com/ar' },
  { ar: 'تواصل معنا لتفاصيل أكثر', en: 'Contact us for more details', link: 'https://wa.me/966558085879' },
  { ar: 'استكشف خدماتنا', en: 'Explore our services', link: 'https://safetyexperts-sa.com/ar' },
];

export default function CalculatorApp({ onNavigateToCertificate }: { onNavigateToCertificate?: () => void }) {
  const [step, setStep] = useState(1);
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [inputs, setInputs] = useState<CalculationInputs>({
    type: BuildingType.RETAIL,
    area: 100,
    floors: 0, 
    hazard: HazardLevel.LOW,
    hasBasement: false,
    numRooms: 0,
    numSections: 0,
    phone: '',
  });
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [showServiceOptions, setShowServiceOptions] = useState(false);

  const handleNext = () => {
    if (step === 2) {
      const res = calculateRequirements(inputs);
      setResult(res);
      setStep(3);
    } else {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const reset = () => {
    setStep(1);
    setResult(null);
  };

  const t = (key: string): string => {
    const dict: Record<string, { ar: string; en: string }> = {
      title: { ar: 'حاسبة متطلبات الدفاع المدني', en: 'Civil Defense Requirements Calculator' },
      step1Title: { ar: 'اختر نوع المنشأة', en: 'Select Facility Type' },
      step1Desc: { ar: 'حدد نوع النشاط الذي ترغب في استخراج المخطط له', en: 'Select the activity type for your plan' },
      step2Title: { ar: 'تفاصيل المساحة', en: 'Area Details' },
      step2Desc: { ar: 'أدخل المساحة التفصيلية والمعلومات الفنية', en: 'Enter detailed area and technical info' },
      area: { ar: 'المساحة الإجمالية (م²)', en: 'Total Area (sqm)' },
      floors: { ar: 'عدد الطوابق', en: 'Number of Floors' },
      rooms: { ar: 'عدد الغرف', en: 'Number of Rooms' },
      sections: { ar: 'عدد الهناجر / الأقسام', en: 'Number of Sections/Warehouses' },
      phone: { ar: 'رقم جوالك (للتواصل)', en: 'Your Mobile Number (for contact)' },
      phoneHint: { ar: 'ادخل 9 أرقام تبدأ بـ 5 (مثال: 504040000)', en: 'Enter 9 digits starting with 5 (e.g., 504040000)' },
      hazard: { ar: 'مستوى الخطورة', en: 'Hazard Level' },
      hasBasement: { ar: 'يتوفر قبو (بدروم)؟', en: 'Has Basement?' },
      low: { ar: 'منخفضة', en: 'Low Hazard' },
      lowDesc: { ar: 'مثل: المكاتب الإدارية، الشقق السكنية، المدارس، المساجد، العيادات الصغيرة.', en: 'e.g. Administrative offices, Residential apartments, Schools, Mosques, Small clinics.' },
      medium: { ar: 'متوسطة', en: 'Medium Hazard' },
      mediumDesc: { ar: 'مثل: المحلات التجارية، المطاعم، الورش الخفيفة، صالات العرض، المستودعات العادية.', en: 'e.g. Retail shops, Restaurants, Light workshops, Showrooms, Regular warehouses.' },
      high: { ar: 'عالية', en: 'High Hazard' },
      highDesc: { ar: 'مثل: مصانع البلاستيك، مستودعات المواد الكيميائية، محطات الوقود، مصانع الأخشاب والورق.', en: 'e.g. Plastic factories, Chemical storage, Gas stations, Wood and paper factories.' },
      resultTitle: { ar: 'حساب المتطلبات جاهز', en: 'Requirements Calculation Ready' },
      cost: { ar: 'التكلفة التقديرية', en: 'Estimated Cost' },
      sar: { ar: 'ر.س', en: 'SAR' },
      requirements: { ar: 'تجهيزات السلامة المطلوبة', en: 'Required Safety Equipment' },
      importantNotes: { ar: 'ملاحظات هامة', en: 'Important Notes' },
      note1: { ar: 'يجب تنفيذ المخطط عن طريق مكتب هندسي معتمد من الدفاع المدني.', en: 'The plan must be executed by an engineering office approved by the Civil Defense.' },
      note2: { ar: 'هذه النتائج تقديرية بناءً على الأكواد العامة وقد تختلف حسب الموقع الدقيق والمتطلبات الهندسية الإضافية.', en: 'These results are estimates based on general codes and may vary based on exact site conditions and additional engineering requirements.' },
      note3: { ar: 'يُشترط توقيع عقد صيانة للكاشفات والأنظمة لضمان مطابقتها لاشتراطات الدفاع المدني.', en: 'A maintenance contract for detectors and systems is required to ensure compliance with Civil Defense regulations.' },
      note4: { ar: 'الأسعار المعروضة هي للمواد الأساسية ولا تشمل أجور التركيب المعقدة أو التمديدات الخاصة.', en: 'Displayed prices are for basic materials and do not include complex installation fees or special wiring.' },
      approvalTime: { ar: 'الوقت التقديري للموافقة:', en: 'Estimated approval time:' },
      days: { ar: 'أيام عمل', en: 'Working Days' },
      printReport: { ar: 'طباعة التقرير', en: 'Print Report' },
      requestService: { ar: 'طلب الخدمة (مخطط/تسعيرة)', en: 'Request Service (Plan/Quote)' },
      call: { ar: 'اتصال', en: 'Call' },
      whatsapp: { ar: 'واتساب', en: 'WhatsApp' },
      next: { ar: 'المرحلة التالية', en: 'Next Stage' },
      calculate: { ar: 'احسب الآن', en: 'Calculate Now' },
      back: { ar: 'السابق', en: 'Back' },
      reset: { ar: 'حساب منشأة أخرى', en: 'Calculate another facility' },
      visitStore: { ar: 'زيارة المتجر', en: 'Visit Store' },
      companyName: { ar: 'مؤسسة خبراء السلامة', en: 'Safety Experts Est.' },
      companySubName: { ar: 'مقاولات عامة', en: 'Safety Systems - General Contracting' },
      featureSBC: { ar: 'مطابق لكود البناء 801', en: 'SBC 801 Compliant' },
      featureReport: { ar: 'تقرير رسمي', en: 'Official Report' },
      featureHazard: { ar: 'تحليل المخاطر', en: 'Hazard Analysis' },
      featureApproved: { ar: 'أنظمة معتمدة', en: 'Approved Systems' },
    };
    return dict[key]?.[lang] || key;
  };

  const handleAction = async (action: string) => {
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, inputs }),
      });
      if (!response.ok) throw new Error('Failed to send');
    } catch (e) {
      console.error(e);
    }
  };

  const isPhoneValid = (phone: string) => /^5[0-9]{8}$/.test(phone);

  const [bannerIndex, setBannerIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setBannerIndex((prev) => (prev + 1) % bannerMessages.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-0 md:py-8 print:p-0" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      {/* Rotating Banner */}
      <div 
        className="mb-6 md:mb-8 cursor-pointer bg-slate-900 border-b-2 border-orange-500 text-white rounded-xl overflow-hidden shadow-md hover:bg-slate-800 transition-colors print:hidden" 
        onClick={() => window.open(bannerMessages[bannerIndex].link, '_blank')}
        title={lang === 'ar' ? bannerMessages[bannerIndex].ar : bannerMessages[bannerIndex].en}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={bannerIndex}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="flex items-center justify-center py-2 px-4 md:py-3 md:px-6 text-center font-bold text-sm md:text-base tracking-wide flex-row gap-2 md:gap-3"
          >
            <span>{lang === 'ar' ? bannerMessages[bannerIndex].ar : bannerMessages[bannerIndex].en}</span>
            <ArrowRight size={18} className={cn("text-orange-400 shrink-0", lang === 'ar' ? "rotate-180" : "")} />
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="text-center mb-6 md:mb-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center justify-center p-2.5 bg-orange-50 text-orange-600 rounded-xl mb-4 shadow-sm"
          title={t('title')}
        >
          <ShieldCheck size={28} />
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-2xl md:text-3xl font-bold text-slate-900 mb-3 tracking-tight"
          title={t('title')}
        >
          {t('title')}
        </motion.h1>
      </div>

      {/* Steps Indicator */}
      <div className="flex items-center justify-center mb-8 md:mb-12 space-x-reverse space-x-4 print:hidden">
        {[1, 2, 3].map((s) => (
          <React.Fragment key={s}>
            <div className={cn(
              "flex items-center justify-center w-10 h-10 rounded-full font-bold transition-all duration-300",
              step >= s ? "bg-orange-500 text-white shadow-lg shadow-orange-200" : "bg-slate-100 text-slate-400"
            )}>
              {s}
            </div>
            {s < 3 && (
              <div className={cn(
                "w-12 h-1 bg-slate-100 rounded-full overflow-hidden",
                step > s && "bg-slate-100"
              )}>
                <motion.div 
                  className="h-full bg-orange-500"
                  animate={{ width: step > s ? '100%' : '0%' }}
                />
              </div>
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Main Content ... rest of the file ...*/}
            {/* Main Content */}
      <div className="bg-white rounded-2xl md:rounded-3xl p-4 md:p-8 border border-slate-100 shadow-xl shadow-slate-200/50 min-h-[300px] md:min-h-[400px] flex flex-col">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div 
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6 md:space-y-8"
            >
              <div className="text-center" title={`${t('step1Title')} - ${t('step1Desc')}`}>
                <h2 className="text-xl md:text-2xl font-bold text-slate-900 mb-2">{t('step1Title')}</h2>
                <p className="text-sm md:text-base text-slate-500">{t('step1Desc')}</p>
              </div>

              <div className="max-w-xl mx-auto w-full">
                <div className="relative group">
                  <select
                    title={t('step1Title')}
                    value={inputs.type}
                    onChange={(e) => setInputs({ ...inputs, type: e.target.value as BuildingType })}
                    className="w-full appearance-none bg-slate-50 border-2 border-slate-100 rounded-2xl px-6 py-5 pr-12 text-lg font-bold text-slate-800 focus:border-orange-500 focus:ring-4 focus:ring-orange-500/10 transition-all cursor-pointer shadow-sm"
                  >
                    {[
                      { id: BuildingType.RETAIL, label: 'محل تجاري | Retail Shop' },
                      { id: BuildingType.WAREHOUSE, label: 'مستودع | Warehouse' },
                      { id: BuildingType.BUILDING, label: 'عمارة سكنية | Building' },
                      { id: BuildingType.OFFICE, label: 'مكتب إداري | Office' },
                      { id: BuildingType.RESTAURANT, label: 'مطعم أو مقهى | Restaurant' },
                      { id: BuildingType.APARTMENT, label: 'شقة سكنية | Apartment' },
                    ].map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                  <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-slate-400 group-hover:text-orange-500 transition-colors">
                    <Building2 size={24} />
                  </div>
                  <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-slate-400">
                    <ChevronDown size={20} />
                  </div>
                </div>
                
                <div className="mt-6 grid grid-cols-2 gap-3 opacity-60">
                   <div className="flex items-center gap-2 text-[10px] text-slate-500 bg-slate-50 p-2 rounded-lg">
                      <ShieldCheck size={14} className="text-orange-500" />
                      <span>متوافق مع الكود السعودي</span>
                   </div>
                   <div className="flex items-center gap-2 text-[10px] text-slate-500 bg-slate-50 p-2 rounded-lg">
                      <FileCheck size={14} className="text-blue-500" />
                      <span>إصدار تقرير فوري</span>
                   </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div 
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-10"
            >
              <div className="text-center" title={`${t('step2Title')} - ${t('step2Desc')}`}>
                <h2 className="text-2xl font-bold text-slate-900 mb-2">{t('step2Title')}</h2>
                <p className="text-slate-500">{t('step2Desc')}</p>
              </div>

              <div className="grid md:grid-cols-2 gap-6 md:gap-8">
                <div className="space-y-6">
                  <div title={t('area')}>
                    <label className="block text-slate-700 font-bold mb-3">{t('area')}</label>
                    <div className="relative">
                      <input 
                        type="number"
                        title={t('area')}
                        value={inputs.area}
                        onChange={(e) => setInputs({ ...inputs, area: Number(e.target.value) })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-xl outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-mono"
                        placeholder="120"
                      />
                    </div>
                  </div>

                  <div title={t('floors')}>
                    <label className="block text-slate-700 font-bold mb-3">{t('floors')}</label>
                      <input 
                        type="number"
                        title={t('floors')}
                        value={inputs.floors}
                        onChange={(e) => setInputs({ ...inputs, floors: Number(e.target.value) })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-xl outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-mono"
                      />
                  </div>
                  
                  <div title={t('phone')}>
                    <label className="block text-slate-700 font-bold mb-3">{t('phone')}</label>
                    <div className="flex items-center gap-2">
                       <div className="bg-slate-100 border border-slate-200 rounded-xl px-4 py-4 text-slate-600 font-bold font-mono text-lg flex items-center gap-2 select-none">
                         <span className="text-xl">🇸🇦</span>
                         <span dir="ltr">+966</span>
                       </div>
                       <div className="relative flex-1">
                        <input 
                          type="tel"
                          title={t('phone')}
                          value={inputs.phone || ''}
                          onChange={(e) => {
                            let val = e.target.value.replace(/\D/g, ''); // Digits only
                            if (val.startsWith('0')) val = val.substring(1); // Remove leading 0
                            if (val.startsWith('966')) val = val.substring(3); // Remove leading 966
                            if (val.length > 9) val = val.substring(0, 9); // Max 9 digits for Saudi mobile (5XXXXXXXX)
                            setInputs({ ...inputs, phone: val });
                          }}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-xl outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-mono"
                          placeholder="5xxxxxxxx"
                          dir="ltr"
                        />
                       </div>
                    </div>
                    <p className="text-slate-400 text-xs mt-2" title={t('phoneHint')}>{t('phoneHint')}</p>
                  </div>
                  
                  {[BuildingType.APARTMENT, BuildingType.BUILDING].includes(inputs.type) && (
                     <div title={t('rooms')}>
                       <label className="block text-slate-700 font-bold mb-3">{t('rooms')}</label>
                       <input 
                        type="number"
                        title={t('rooms')}
                        value={inputs.numRooms || 0}
                        onChange={(e) => setInputs({ ...inputs, numRooms: Number(e.target.value) })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-xl outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-mono"
                       />
                     </div>
                  )}

                  {[BuildingType.WAREHOUSE, BuildingType.FACTORY].includes(inputs.type as any) && (
                     <div title={t('sections')}>
                       <label className="block text-slate-700 font-bold mb-3">{t('sections')}</label>
                       <input 
                        type="number"
                        title={t('sections')}
                        value={inputs.numSections || 0}
                        onChange={(e) => setInputs({ ...inputs, numSections: Number(e.target.value) })}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-xl outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-mono"
                       />
                     </div>
                  )}
                </div>

                <div className="space-y-6">
                  <div title={t('hazard')}>
                    <label className="block text-slate-700 font-bold mb-3">{t('hazard')}</label>
                    <div className="space-y-3">
                      {[
                        { id: HazardLevel.LOW, label: t('low'), desc: t('lowDesc') },
                        { id: HazardLevel.MEDIUM, label: t('medium'), desc: t('mediumDesc') },
                        { id: HazardLevel.HIGH, label: t('high'), desc: t('highDesc') },
                      ].map((h) => (
                        <button
                          key={h.id}
                          type="button"
                          title={`${h.label} - ${h.desc}`}
                          onClick={() => setInputs({ ...inputs, hazard: h.id })}
                          className={cn(
                            "w-full text-right px-5 py-4 rounded-xl border-2 transition-all flex items-start justify-between gap-4",
                            inputs.hazard === h.id 
                              ? "bg-orange-50 border-orange-500 text-orange-600" 
                              : "bg-white border-slate-100 text-slate-500 hover:bg-orange-50 hover:border-orange-200"
                          )}
                        >
                          <div className="flex flex-col gap-1">
                            <span className="font-bold text-slate-800 text-lg">{h.label}</span>
                            <span className={cn("text-xs leading-relaxed text-right", inputs.hazard === h.id ? "text-orange-600/80" : "text-slate-400")}>{h.desc}</span>
                          </div>
                          <div className="pt-1">
                            {inputs.hazard === h.id && <CheckCircle2 size={24} className="text-orange-500" />}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl" title={t('hasBasement')}>
                    <div className="flex items-center gap-3">
                      <div className="bg-white p-2 rounded-lg shadow-sm">
                        <Home size={20} className="text-slate-500"  />
                      </div>
                      <span className="font-bold text-slate-700">{t('hasBasement')}</span>
                    </div>
                    <button 
                      type="button"
                      title={t('hasBasement')}
                      onClick={() => setInputs({ ...inputs, hasBasement: !inputs.hasBasement })}
                      className={cn(
                        "w-14 h-8 rounded-full p-1 transition-colors duration-200 ease-in-out relative",
                        inputs.hasBasement ? "bg-orange-500" : "bg-slate-300"
                      )}
                    >
                      <div className={cn(
                        "w-6 h-6 bg-white rounded-full shadow transform transition-transform duration-200",
                        inputs.hasBasement ? "-translate-x-6" : "translate-x-0"
                      )} />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && result && (
            <motion.div 
              id="calculator-report"
              key="step3"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8 p-1"
            >
              <div className="flex flex-col md:flex-row items-center justify-between text-center md:text-start bg-emerald-50 border border-emerald-100 p-5 md:p-6 rounded-2xl gap-4" title={t('resultTitle')}>
                <div className="flex items-center gap-4">
                  <div className="bg-emerald-500 text-white p-3 rounded-full shadow-lg shadow-emerald-200">
                    <CheckCircle2 size={32}  />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-emerald-900">{t('resultTitle')}</h2>
                    <p className="text-emerald-700 hover:text-emerald-800" title={`بناءً على مساحة ${inputs.area} م² ونوع المنشأة (${inputs.type})`}>بناءً على مساحة {inputs.area} م² ونوع المنشأة ({inputs.type})</p>
                  </div>
                </div>
                <div className="text-center md:text-left bg-white px-6 py-4 md:py-3 rounded-xl shadow-sm border border-emerald-100 w-full md:w-auto" title={`${t('cost')}: ${result.estimatedCostRange.min.toLocaleString()} - ${result.estimatedCostRange.max.toLocaleString()} ${t('sar')}`}>
                  <span className="text-xs text-slate-500 block">{t('cost')}</span>
                  <span className="text-2xl font-bold text-slate-900 font-mono">
                    {result.estimatedCostRange.min.toLocaleString()} - {result.estimatedCostRange.max.toLocaleString()}
                  </span>
                  <span className="text-sm font-bold text-slate-500 mr-2 uppercase">{t('sar')}</span>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-bold text-slate-800 flex items-center gap-2" title={t('requirements')}>
                    <ShieldCheck size={20} className="text-orange-500"  />
                    {t('requirements')}
                  </h3>
                  <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden divide-y divide-slate-100 shadow-sm">
                    {result.requirements.map((req) => (
                      <div key={req.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors" title={`${req.nameAr} - ${req.quantity} ${req.unitAr} ${req.noteAr ? `(${req.noteAr})` : ''}`}>
                        <div>
                          <div className="font-bold text-slate-900">{req.nameAr}</div>
                          {req.noteAr && <div className="text-xs text-orange-500 mt-1">{req.noteAr}</div>}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="bg-orange-50 text-orange-600 font-black px-3 py-1 rounded-lg text-sm">
                            {req.quantity}
                          </span>
                          <span className="text-xs text-slate-500">{req.unitAr}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl">
                    <div className="flex items-center gap-3 mb-4" title={t('importantNotes')}>
                      <Info className="text-blue-600" size={24}  />
                      <h3 className="font-bold text-blue-900">{t('importantNotes')}</h3>
                    </div>
                    <ul className="space-y-3 text-blue-800 text-sm">
                      <li className="flex gap-2" title={t('note1')}>
                        <span className="text-blue-400">•</span>
                        <span>{t('note1')}</span>
                      </li>
                      <li className="flex gap-2" title={t('note2')}>
                        <span className="text-blue-400">•</span>
                        <span>{t('note2')}</span>
                      </li>
                      <li className="flex gap-2" title={t('note3')}>
                        <span className="text-blue-400">•</span>
                        <span>{t('note3')}</span>
                      </li>
                      <li className="flex gap-2" title={t('note4')}>
                        <span className="text-blue-400">•</span>
                        <span>{t('note4')}</span>
                      </li>
                      <li className="flex gap-3 font-bold mt-5 pt-4 border-t border-blue-200/50 items-center" title={`${t('approvalTime')} ${result.processingTimeDays} ${t('days')}`}>
                        <span className="text-blue-500 bg-blue-100 p-1.5 rounded-lg flex items-center justify-center">⏱</span>
                        <span>{t('approvalTime')} {result.processingTimeDays} {t('days')}</span>
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-6 print:hidden">
                    <button 
                      type="button" 
                      title="تحقق من أهلية إصدار شهادة السلامة"
                      onClick={onNavigateToCertificate}
                      className="w-full bg-blue-50 text-blue-700 border-2 border-blue-200 rounded-2xl p-4 font-bold flex items-center justify-center gap-3 hover:bg-blue-100 transition-all group"
                    >
                      <ShieldCheck size={24} className="group-hover:scale-110 transition-transform" />
                      {lang === 'ar' ? 'فحص أهلية شهادة السلامة لهذا النشاط' : 'Check safety certificate eligibility'}
                    </button>

                    <div className="grid grid-cols-2 gap-4">
                      <button 
                        type="button" 
                        title="تحميل التقرير بصيغة PDF" 
                        onClick={() => { 
                          generatePDF('calculator-report', `تقرير_دفاع_مدني_${inputs.area}م`); 
                          handleAction('تحميل تقرير PDF'); 
                        }} 
                        className="bg-slate-900 text-white rounded-2xl p-4 font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-colors"
                      >
                        <Download size={20} />
                        {lang === 'ar' ? 'تحميل PDF' : 'Download PDF'}
                      </button>
                      <button 
                         type="button" 
                         title="طباعة التقرير" 
                         onClick={() => { window.print(); handleAction('طباعة تقرير'); }} 
                         className="bg-slate-100 text-slate-800 rounded-2xl p-4 font-bold flex items-center justify-center gap-2 hover:bg-slate-200 transition-colors"
                       >
                        <Download size={20} className="rotate-180" />
                        {t('printReport')}
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <button 
                        type="button" 
                        title={t('call')}
                        onClick={() => { 
                          const phoneNum = inputs.phone || '966558085879';
                          handleAction('طلب اتصال');
                          window.location.href = `tel:${phoneNum.startsWith('966') ? phoneNum : `966${phoneNum}`}`;
                        }}
                        className="bg-orange-600 text-white rounded-2xl p-4 font-bold flex items-center justify-center gap-2 hover:bg-orange-700 transition-colors"
                      >
                        <Phone size={20}  />
                        {t('call')}
                      </button>
                      <button 
                        type="button" 
                        title={t('whatsapp')}
                        onClick={() => { 
                          const message = formatWhatsAppMessage('تقرير حاسبة الدفاع المدني', {
                            activity: inputs.type,
                            area: inputs.area,
                            hazard: inputs.hazard === HazardLevel.LOW ? 'منخفضة' : inputs.hazard === HazardLevel.MEDIUM ? 'متوسطة' : 'عالية',
                            result: `${result.estimatedCostRange.min} - ${result.estimatedCostRange.max} ر.س`
                          });
                          handleAction('مشاركة واتساب');
                          window.open(`https://wa.me/966558085879?text=${message}`, '_blank');
                        }}
                        className="bg-green-600 text-white rounded-2xl p-4 font-bold flex items-center justify-center gap-2 hover:bg-green-700 transition-colors shadow-lg shadow-green-100"
                      >
                        <MessageCircle size={20}  />
                        {t('whatsapp')}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer Actions */}
        <div className="mt-auto pt-8 md:pt-10 flex flex-col-reverse md:flex-row items-center justify-between gap-4 border-t border-slate-50 print:hidden">
          {step > 1 && (
            <button 
              type="button"
              title={t('back')}
              onClick={handleBack}
              className="w-full md:w-auto justify-center bg-slate-100 text-slate-700 px-8 py-3 rounded-xl font-bold hover:bg-slate-200 transition-colors flex items-center gap-2"
            >
              <ChevronRight size={20}  />
              {t('back')}
            </button>
          )}
          
          <div className="mr-auto w-full md:w-auto">
            {step === 3 ? (
              <button 
                type="button"
                title={t('reset')}
                onClick={reset}
                className="w-full md:w-auto justify-center bg-slate-100 text-slate-700 px-8 py-3 rounded-xl font-bold hover:bg-slate-200 transition-colors"
              >
                {t('reset')}
              </button>
            ) : (
              <button 
                type="button"
                title={step === 2 ? t('calculate') : t('next')}
                onClick={handleNext}
                disabled={step === 2 && inputs.area <= 0}
                className={cn(
                  "w-full md:w-auto flex items-center justify-center gap-2 bg-orange-500 text-white px-12 py-4 rounded-2xl font-bold transition-all shadow-lg hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-95",
                  "shadow-orange-200"
                )}
              >
                {step === 2 ? t('calculate') : t('next')}
                {step === 2 ? <CalcIcon size={20}  /> : <ChevronLeft size={20}  />}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Trust Badges */}
      <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 opacity-70 hover:opacity-100 transition-all duration-500">
        <motion.div whileHover={{ scale: 1.05 }} className="flex flex-col items-center" title={t('featureSBC')}>
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}>
            <ShieldCheck size={32} className="mb-2 text-slate-700"  />
          </motion.div>
          <span className="text-[10px] font-bold text-center uppercase tracking-widest text-slate-900">{t('featureSBC')}</span>
        </motion.div>
        
        <motion.div whileHover={{ scale: 1.05 }} className="flex flex-col items-center" title={t('featureReport')}>
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut", delay: 0.2 }}>
            <FileText size={32} className="mb-2 text-slate-700"  />
          </motion.div>
          <span className="text-[10px] font-bold text-center uppercase tracking-widest text-slate-900">{t('featureReport')}</span>
        </motion.div>

        <motion.div whileHover={{ scale: 1.05 }} className="flex flex-col items-center" title={t('featureHazard')}>
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut", delay: 0.4 }}>
            <AlertTriangle size={32} className="mb-2 text-slate-700"  />
          </motion.div>
          <span className="text-[10px] font-bold text-center uppercase tracking-widest text-slate-900">{t('featureHazard')}</span>
        </motion.div>

        <motion.div whileHover={{ scale: 1.05 }} className="flex flex-col items-center" title={t('featureApproved')}>
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut", delay: 0.6 }}>
            <CheckCircle2 size={32} className="mb-2 text-slate-700"  />
          </motion.div>
          <span className="text-[10px] font-bold text-center uppercase tracking-widest text-slate-900">{t('featureApproved')}</span>
        </motion.div>
      </div>

      {/* Footer */}
      <footer className="mt-12 text-center text-sm text-slate-500">
        <p>جميع الحقوق محفوظة لـ <span className="font-bold">مؤسسة خبراء السلامة لأنظمة السلامة</span> &copy; {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
}
