
'use client';

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, 
  Search,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ArrowRight,
  Zap,
  Clock,
  ExternalLink,
  MessageCircle,
  Hash,
  Info,
  ChevronDown,
  Download,
  FileText
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { SALAMA_ACTIVITIES, Activity } from '@/lib/activities-data';
import { generatePDF, formatWhatsAppMessage } from '@/lib/report-generator';

enum SizeCategory {
  SMALL = 'small',
  MEDIUM = 'medium',
  LARGE = 'large',
}

type EligibilityResult = {
  status: 'success' | 'warning' | 'danger';
  title: string;
  price?: string;
  message: string;
  requirements?: string[];
  warningNote?: string;
  actionLabel: string;
  actionLink: string;
};

export default function SafetyCertificateCheck() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [area, setArea] = useState<number | ''>('');
  const [hasRisk, setHasRisk] = useState<boolean>(false);
  const [isReady, setIsReady] = useState<boolean>(true);
  const [result, setResult] = useState<EligibilityResult | null>(null);
  
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredActivities = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    if (term === "") {
      return SALAMA_ACTIVITIES.slice(0, 30);
    }
    
    // Improved search: check ID first, then name, then allow partial matches within name
    return SALAMA_ACTIVITIES.filter(a => {
      const matchId = a.id.toLowerCase().startsWith(term);
      const matchName = a.name.toLowerCase().includes(term);
      return matchId || matchName;
    }).sort((a, b) => {
      // Prioritize ID starts with matches
      const aStarts = a.id.startsWith(term) ? 0 : 1;
      const bStarts = b.id.startsWith(term) ? 0 : 1;
      return aStarts - bStarts;
    }).slice(0, 15);
  }, [searchTerm]);

  const calculateEligibility = () => {
    if (!selectedActivity || area === "") return;

    const areaValue = Number(area);
    const isLargeArea = areaValue > 150;
    const isMediumArea = areaValue >= 50 && areaValue <= 150;
    const isSmallArea = areaValue < 50;

    const isHighRiskActivity = selectedActivity.category === 'high';
    const isMediumRiskActivity = selectedActivity.category === 'medium';

    const baseResult = {
      requirements: selectedActivity.requirements,
      warningNote: selectedActivity.warningNote,
      actionLink: 'https://wa.me/966558085879',
    };

    if (selectedActivity.category === 'simple' && isSmallArea && !hasRisk && isReady) {
      setResult({
        ...baseResult,
        status: 'success',
        title: 'أهلية إصدار فورية',
        price: selectedActivity.basePrice,
        message: `تم التحقق من نشاط (${selectedActivity.name}). النشاط يندرج تحت الفئة البسيطة والمساحة متوافقة، يمكنك البدء في الإصدار الآن.`,
        actionLabel: 'اطلب الخدمة الآن',
        actionLink: 'https://safetyexperts-sa.com/ar',
      });
    } else if (isHighRiskActivity || isLargeArea || hasRisk) {
      setResult({
        ...baseResult,
        status: 'danger',
        title: 'يتطلب دراسة هندسية ومعاينة',
        message: `بناءً على طبيعة النشاط (${selectedActivity.name}) والمساحة (${area} م²)، يتطلب النظام معاينة ميدانية من قبل مهندس سلامة معتمد للتأكد من مطابقة الأنظمة لاشتراطات الدفاع المدني.`,
        actionLabel: 'طلب معاينة موقع',
      });
    } else {
      setResult({
        ...baseResult,
        status: 'warning',
        title: 'متطلبات تجهيز وتدقيق',
        price: selectedActivity.basePrice !== 'اتصل بنا' ? `يبدأ من ${selectedActivity.basePrice}` : undefined,
        message: `النشاط (${selectedActivity.name}) بمساحة (${area} م²) يتطلب توفير الحد الأدنى من أدوات السلامة (طفايات، كواشف، لوحات إرشادية). فريقنا سيقوم بمراجعة جاهزيتك قبل الإصدار.`,
        actionLabel: 'تواصل مع مستشار',
      });
    }
  };

  const reset = () => {
    setResult(null);
    setSelectedActivity(null);
    setSearchTerm('');
    setArea('');
  };

  return (
    <div className="w-full space-y-8">
      <div className="text-center space-y-3">
        <div className="inline-flex items-center justify-center p-3 bg-blue-50 text-blue-600 rounded-2xl shadow-sm">
          <ShieldCheck size={32} />
        </div>
        <h2 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight">نظام فحص أهلية شهادة السلامة</h2>
        <p className="text-slate-500 max-w-lg mx-auto">أدخل اسم النشاط أو رقم الكود كما هو مسجل في منصة &quot;سلامة&quot; للتحقق من المتطلبات.</p>
      </div>

      <div className="bg-white rounded-3xl p-6 md:p-10 border border-slate-100 shadow-xl shadow-slate-200/50">
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {/* Activity Selection with Search */}
              <div className="space-y-4 relative" ref={dropdownRef}>
                <label className="block text-slate-700 font-bold flex items-center gap-2">
                  <Search size={20} className="text-blue-500" />
                  البحث عن النشاط المسجل
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="اكتب اسم النشاط أو الكود... (مثلاً: 561010)"
                    className="w-full p-4 pr-12 pl-12 rounded-2xl border-2 border-slate-200 focus:border-blue-500 transition-all outline-none text-right bg-slate-50 font-bold"
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value);
                      setIsDropdownOpen(true);
                      if (selectedActivity && e.target.value !== selectedActivity.name) {
                        setSelectedActivity(null);
                      }
                    }}
                    onFocus={() => setIsDropdownOpen(true)}
                  />
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
                  
                  <button 
                    type="button"
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-2 hover:bg-slate-200 rounded-lg transition-colors text-slate-500"
                    title="استعراض الكل"
                  >
                    <ChevronDown className={cn("transition-transform duration-300", isDropdownOpen && "rotate-180")} size={20} />
                  </button>
                  
                  {isDropdownOpen && (
                    <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 max-h-80 overflow-y-auto overflow-x-hidden p-2">
                      {filteredActivities.length > 0 ? (
                        filteredActivities.map((activity) => (
                          <button
                            key={activity.id}
                            onClick={() => {
                              setSelectedActivity(activity);
                              setSearchTerm(activity.name);
                              setIsDropdownOpen(false);
                            }}
                            className="w-full p-4 text-right hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-0 flex items-center justify-between group rounded-xl"
                          >
                            <div className="flex flex-col gap-1">
                              <span className="font-bold text-slate-700 group-hover:text-blue-700">{activity.name}</span>
                              <div className="flex items-center gap-2 text-[10px] text-slate-400">
                                <Hash size={10} />
                                <span>{activity.id}</span>
                              </div>
                            </div>
                            <span className={cn(
                              "text-[10px] px-2 py-1 rounded-full uppercase font-bold whitespace-nowrap mr-2",
                              activity.category === 'simple' ? "bg-emerald-100 text-emerald-700" :
                              activity.category === 'medium' ? "bg-orange-100 text-orange-700" :
                              "bg-red-100 text-red-700"
                            )}>
                              {activity.category === 'simple' ? 'بسيط' : activity.category === 'medium' ? 'متوسط' : 'عالي الخطورة'}
                            </span>
                          </button>
                        ))
                      ) : (
                        <div className="p-8 text-center text-slate-400">
                          <Info size={32} className="mx-auto mb-2 opacity-20" />
                          <p>لا توجد نتائج مطابقة، جرب كلمات أخرى</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                {selectedActivity && (
                  <div className="flex items-center justify-between text-emerald-600 bg-emerald-50 p-4 rounded-xl border border-emerald-100">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={18} />
                      <span className="font-bold"> النشاط المختار: {selectedActivity.name}</span>
                    </div>
                    <span className="text-xs font-mono opacity-60">#{selectedActivity.id}</span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                {/* Area Input */}
                <div className="space-y-4">
                  <label className="block text-slate-700 font-bold flex items-center gap-2">
                    <ExternalLink size={20} className="text-blue-500" />
                    مساحة الموقع (متر مربع)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      placeholder="مثال: 75"
                      className="w-full p-5 rounded-2xl border-2 border-slate-200 focus:border-blue-500 transition-all outline-none text-right bg-slate-50 font-bold text-lg pr-12"
                      value={area}
                      onChange={(e) => setArea(e.target.value === '' ? '' : Number(e.target.value))}
                    />
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">م²</div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { val: 40, label: 'صغير' },
                      { val: 100, label: 'متوسط' },
                      { val: 200, label: 'كبير' },
                    ].map((btn) => (
                      <button
                        key={btn.val}
                        onClick={() => setArea(btn.val)}
                        className="py-2 text-[10px] font-bold bg-slate-100 text-slate-500 rounded-lg hover:bg-blue-100 hover:text-blue-600 transition-colors"
                      >
                        {btn.label} ({btn.val}م²)
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <label className="block text-slate-700 font-bold">معايير السلامة الإضافية</label>
                  {/* Hazard Toggle */}
                  <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="flex flex-col gap-1">
                      <span className="font-bold text-slate-800">غاز أو مواد سريعة الاشتعال؟</span>
                      <span className="text-xs text-slate-500">مواقد، أنابيب غاز، مواد كيميائية.</span>
                    </div>
                    <button 
                      onClick={() => setHasRisk(!hasRisk)}
                      className={cn(
                        "w-14 h-8 rounded-full p-1 transition-colors duration-300 relative",
                        hasRisk ? "bg-orange-500" : "bg-slate-300"
                      )}
                    >
                      <div className={cn(
                        "w-6 h-6 bg-white rounded-full shadow-md transform transition-transform duration-300",
                        hasRisk ? "-translate-x-6" : "translate-x-0"
                      )} />
                    </button>
                  </div>

                  {/* Readiness Toggle */}
                  <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="flex flex-col gap-1">
                      <span className="font-bold text-slate-800">هل الموقع يحتوي على معدات السلامة؟</span>
                      <span className="text-xs text-slate-500">مطفأة حريق - كاشف دخان - علامات خروج</span>
                    </div>
                    <button 
                      onClick={() => setIsReady(!isReady)}
                      className={cn(
                        "w-14 h-8 rounded-full p-1 transition-colors duration-300 relative",
                        isReady ? "bg-emerald-500" : "bg-slate-300"
                      )}
                    >
                      <div className={cn(
                        "w-6 h-6 bg-white rounded-full shadow-md transform transition-transform duration-300",
                        isReady ? "-translate-x-6" : "translate-x-0"
                      )} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-slate-50">
                <button
                  disabled={!selectedActivity || area === ''}
                  onClick={calculateEligibility}
                  className={cn(
                    "w-full py-5 rounded-2xl font-bold text-lg shadow-lg flex items-center justify-center gap-3 transition-all transform active:scale-95",
                    (selectedActivity && area !== '') 
                      ? "bg-blue-600 text-white shadow-blue-200 hover:bg-blue-700" 
                      : "bg-slate-200 text-slate-400 cursor-not-allowed"
                  )}
                >
                  تحليل الأهلية والتكلفة
                  <ArrowRight size={20} className="rotate-180" />
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              id="eligibility-report"
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-8"
            >
              <div className={cn(
                "p-8 rounded-3xl border text-center space-y-4",
                result.status === 'success' ? "bg-emerald-50 border-emerald-100" :
                result.status === 'warning' ? "bg-orange-50 border-orange-100" :
                "bg-red-50 border-red-100"
              )}>
                <div className="flex justify-center">
                  {result.status === 'success' ? <CheckCircle2 size={64} className="text-emerald-500" /> :
                   result.status === 'warning' ? <AlertTriangle size={64} className="text-orange-500" /> :
                   <XCircle size={64} className="text-red-500" />}
                </div>
                <h3 className={cn(
                  "text-2xl font-bold",
                  result.status === 'success' ? "text-emerald-900" :
                  result.status === 'warning' ? "text-orange-900" :
                  "text-red-900"
                )}>
                  {result.title}
                </h3>
                
                {result.price && (
                  <div className="inline-block py-2 px-6 bg-white rounded-2xl shadow-sm border border-slate-100 mb-2">
                    <span className="text-slate-500 text-[10px] block mb-1">التكلفة التقديرية للإصدار</span>
                    <span className="text-2xl font-black text-slate-900">{result.price}</span>
                  </div>
                )}
                
                <p className="text-slate-700 leading-relaxed max-w-md mx-auto font-medium">
                  {result.message}
                </p>

                {result.requirements && result.requirements.length > 0 && (
                  <div className="mt-6 text-right bg-white/50 backdrop-blur-sm rounded-2xl p-5 border border-slate-200/50">
                    <h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
                      <ShieldCheck size={16} className="text-blue-500" />
                      المتطلبات التشغيلية للنشاط:
                    </h4>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {result.requirements.map((req, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-slate-600">
                          <CheckCircle2 size={12} className="text-emerald-500" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {result.warningNote && (
                  <div className="mt-4 p-4 bg-red-50/50 rounded-xl border border-red-100/50 flex align-start gap-3 text-right">
                    <AlertTriangle size={20} className="text-red-500 shrink-0 mt-0.5" />
                    <p className="text-xs text-red-800 leading-normal">
                      <span className="font-bold underline block mb-1">تنبيه فني هام:</span>
                      {result.warningNote}
                    </p>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => {
                     const message = formatWhatsAppMessage('فحص أهلية شهادة سلامة', {
                       activity: selectedActivity?.name,
                       area: area,
                       hazard: hasRisk ? 'يوجد مخاطر (غاز/مواد)' : 'لا يوجد مخاطر خاصة',
                       result: result.title
                     });
                     window.open(`https://wa.me/966558085879?text=${message}`, '_blank');
                  }}
                  className={cn(
                    "flex-1 py-4 rounded-2xl font-bold text-center transition-all flex items-center justify-center gap-2",
                    result.status === 'success' ? "bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-200" :
                    result.status === 'warning' ? "bg-orange-600 text-white hover:bg-orange-700 shadow-lg shadow-orange-200" :
                    "bg-slate-900 text-white hover:bg-black shadow-lg shadow-slate-200"
                  )}
                >
                  <MessageCircle size={20} />
                  {result.actionLabel}
                </button>
                
                <div className="grid grid-cols-2 gap-2">
                   <button
                    onClick={() => generatePDF('eligibility-report', `تقرير_أهلية_${selectedActivity?.id}`)}
                    className="py-4 border-2 border-slate-100 rounded-2xl font-bold text-slate-600 hover:bg-slate-50 transition-all flex items-center justify-center gap-2"
                  >
                    <Download size={18} />
                    <span>PDF</span>
                  </button>
                  <button
                    onClick={reset}
                    className="py-4 border-2 border-slate-100 rounded-2xl font-bold text-slate-600 hover:bg-slate-50 transition-all"
                  >
                    فحص آخر
                  </button>
                </div>
              </div>

              <div className="bg-slate-900 p-6 rounded-2xl border-b-4 border-orange-500 text-white">
                <h4 className="font-bold mb-4 flex items-center gap-2">
                  <Clock size={18} className="text-orange-400" />
                  إرشادات منصة سلامة
                </h4>
                <ul className="space-y-3 text-xs text-slate-300 leading-normal">
                  <li className="flex gap-2">
                    <span className="text-orange-400 font-bold">•</span>
                    <span>يجب أن يكون عقد الإيجار سري المفعول وموثقاً في &quot;إيجار&quot;.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-orange-400 font-bold">•</span>
                    <span>في حال وجود نشاط إضافي (سكني أو تخزيني) يجب ذكره بوضوح.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-orange-400 font-bold">•</span>
                    <span>المكاتب الهندسية تضمن لك صحة البيانات القانونية لتجنب المخالفات.</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
